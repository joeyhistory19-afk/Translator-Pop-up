package com.example

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.media.projection.MediaProjectionManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.FloatingBubbleService
import com.example.service.ManhwaAccessibilityService
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            startTranslatorService(result.resultCode, result.data!!)
        } else {
            Toast.makeText(this, "Izin perekaman layar dibutuhkan untuk mendeteksi teks manhwa", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = true, dynamicColor = false) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainScreen()
                }
            }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun MainScreen() {
        var isServiceRunning by remember { mutableStateOf(FloatingBubbleService.isRunning) }
        var isOverlayGranted by remember { mutableStateOf(Settings.canDrawOverlays(this)) }
        var isAccessibilityGranted by remember { mutableStateOf(isAccessibilityServiceEnabled(this)) }

        // Periodically refresh states when screen resumes
        DisposableEffect(Unit) {
            val handler = android.os.Handler(android.os.Looper.getMainLooper())
            val runnable = object : Runnable {
                override fun run() {
                    isServiceRunning = FloatingBubbleService.isRunning
                    isOverlayGranted = Settings.canDrawOverlays(this@MainActivity)
                    isAccessibilityGranted = isAccessibilityServiceEnabled(this@MainActivity)
                    handler.postDelayed(this, 1000)
                }
            }
            handler.post(runnable)
            onDispose {
                handler.removeCallbacks(runnable)
            }
        }

        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Text(
                            "MANHWA TRANSLATOR",
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp,
                            fontSize = 20.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background
                    )
                )
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Onboarding Hero Header
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.manhwa_translator_hero_1783006419786),
                        contentDescription = "Manhwa Translator Hero Banner",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    // Semi-transparent gradient overlay for textual contrast
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f))
                                )
                            )
                    )
                    Text(
                        text = "Terjemahkan Manhwa Secara Instan!",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(16.dp)
                    )
                }

                // Short Introduction Description
                Text(
                    text = "Aplikasi ini mempermudah membaca Manhwa/Manga berbahasa Inggris dengan mendeteksi teks pada area layar secara cepat menggunakan AI Gemini.",
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(horizontal = 12.dp)
                )

                // Service Power Toggle Button (Sophisticated Dark Design style)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            width = 1.dp,
                            color = MaterialTheme.colorScheme.outline,
                            shape = RoundedCornerShape(16.dp)
                        ),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Header Status Row matching Design HTML
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("✨", fontSize = 18.sp)
                                }
                                Column {
                                    Text(
                                        text = "Status Layanan",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = if (isServiceRunning) "Running in background" else "Stopped / Idle",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isServiceRunning) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            // Custom switch toggle aesthetic
                            Box(
                                modifier = Modifier
                                    .width(48.dp)
                                    .height(24.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isServiceRunning) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.outline
                                    )
                                    .clickable {
                                        if (isServiceRunning) {
                                            stopTranslatorService()
                                        } else {
                                            if (!isOverlayGranted) {
                                                Toast.makeText(this@MainActivity, "Harap izinkan Draw Over Other Apps terlebih dahulu!", Toast.LENGTH_LONG).show()
                                                requestOverlayPermission()
                                            } else {
                                                requestScreenCapture()
                                            }
                                        }
                                    }
                                    .padding(horizontal = 4.dp),
                                contentAlignment = if (isServiceRunning) Alignment.CenterEnd else Alignment.CenterStart
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isServiceRunning) MaterialTheme.colorScheme.onPrimary
                                            else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                )
                            }
                        }

                        // Big Action Button
                        Button(
                            onClick = {
                                if (isServiceRunning) {
                                    stopTranslatorService()
                                } else {
                                    if (!isOverlayGranted) {
                                        Toast.makeText(this@MainActivity, "Harap izinkan Draw Over Other Apps terlebih dahulu!", Toast.LENGTH_LONG).show()
                                        requestOverlayPermission()
                                    } else {
                                        requestScreenCapture()
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isServiceRunning) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                                contentColor = if (isServiceRunning) MaterialTheme.colorScheme.onError else MaterialTheme.colorScheme.onPrimary
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = if (isServiceRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                                contentDescription = null
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                if (isServiceRunning) "Hentikan Layanan" else "Aktifkan Tombol Melayang",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Permissions Checklist Section
                Text(
                    text = "KONTROL IZIN APLIKASI",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.align(Alignment.Start)
                )

                PermissionCard(
                    title = "Draw Over Other Apps (Overlay)",
                    desc = "Wajib aktif agar tombol melayang dapat ditampilkan di atas aplikasi lain.",
                    isGranted = isOverlayGranted,
                    onClick = { requestOverlayPermission() }
                )

                PermissionCard(
                    title = "Media Projection (Screen Capture)",
                    desc = "Izin mengambil cuplikan area layar saat mendeteksi teks manhwa.",
                    isGranted = isServiceRunning, // active if service is running with valid projection token
                    onClick = { 
                        if (!isServiceRunning) {
                            if (!isOverlayGranted) {
                                Toast.makeText(this@MainActivity, "Harap izinkan Draw Over Other Apps terlebih dahulu!", Toast.LENGTH_SHORT).show()
                                requestOverlayPermission()
                            } else {
                                requestScreenCapture()
                            }
                        }
                    }
                )

                PermissionCard(
                    title = "Layanan Aksesibilitas (Opsional)",
                    desc = "Membantu melancarkan interaksi di latar belakang (Buka Pengaturan > Manhwa Translator).",
                    isGranted = isAccessibilityGranted,
                    onClick = { requestAccessibilityPermission() }
                )

                // Tutorial Steps Section
                Text(
                    text = "CARA PENGGUNAAN",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.align(Alignment.Start)
                )

                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TutorialItem(step = "1", title = "Aktifkan Tombol", desc = "Klik tombol 'Aktifkan Tombol Melayang' di atas dan setujui izin perekaman layar.")
                    TutorialItem(step = "2", title = "Buka Manhwa Inggris", desc = "Buka komik/manhwa favorit Anda di Chrome, Webtoon, atau aplikasi apa saja.")
                    TutorialItem(step = "3", title = "Seleksi Area Teks", desc = "Klik tombol melayang terjemah, lalu seret kotak hijau mengelilingi balon teks bahasa Inggris.")
                    TutorialItem(step = "4", title = "Terjemahan Instan", desc = "Tekan 'Terjemahkan', hasil terjemahan Bahasa Indonesia yang ekspresif akan langsung muncul!")
                }

                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }

    @Composable
    fun PermissionCard(
        title: String,
        desc: String,
        isGranted: Boolean,
        onClick: () -> Unit
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(
                    width = 1.dp,
                    color = MaterialTheme.colorScheme.outline,
                    shape = RoundedCornerShape(16.dp)
                )
                .clickable { onClick() },
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = desc,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                
                // Beautiful status badge matching the Design theme
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            if (isGranted) MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                            else MaterialTheme.colorScheme.primaryContainer
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isGranted) "GRANTED" else "REQUIRED",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isGranted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onPrimaryContainer,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }

    @Composable
    fun TutorialItem(step: String, title: String, desc: String) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = step,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 14.sp
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = desc,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                )
            }
        }
    }

    private fun requestOverlayPermission() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }

    private fun requestAccessibilityPermission() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        startActivity(intent)
    }

    private fun requestScreenCapture() {
        val mediaProjectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val intent = mediaProjectionManager.createScreenCaptureIntent()
        screenCaptureLauncher.launch(intent)
    }

    private fun startTranslatorService(resultCode: Int, data: Intent) {
        val intent = Intent(this, FloatingBubbleService::class.java).apply {
            action = FloatingBubbleService.ACTION_START
            putExtra(FloatingBubbleService.EXTRA_RESULT_CODE, resultCode)
            putExtra(FloatingBubbleService.EXTRA_RESULT_DATA, data)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun stopTranslatorService() {
        val intent = Intent(this, FloatingBubbleService::class.java).apply {
            action = FloatingBubbleService.ACTION_STOP
        }
        startService(intent)
    }

    private fun isAccessibilityServiceEnabled(context: Context): Boolean {
        val expectedId = "${context.packageName}/${ManhwaAccessibilityService::class.java.canonicalName}"
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.contains(expectedId)
    }
}
