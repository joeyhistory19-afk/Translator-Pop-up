package com.example.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class ManhwaAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Layanan ini hanya deklarasi izin pembantu sesuai request user
    }

    override fun onInterrupt() {
        // Layanan diinterupsi
    }
}
