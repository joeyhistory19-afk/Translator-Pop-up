package com.example.service

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.api.GeminiTranslator
import com.example.ui.theme.MyApplicationTheme
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.*

class FloatingBubbleService : Service(), LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {

    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val EXTRA_RESULT_CODE = "EXTRA_RESULT_CODE"
        const val EXTRA_RESULT_DATA = "EXTRA_RESULT_DATA"

        private const val CHANNEL_ID = "manhwa_translator_channel"
        private const val NOTIFICATION_ID = 48512

        @Volatile
        var isRunning = false
    }

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store

    private lateinit var windowManager: WindowManager
    private lateinit var mediaProjectionManager: MediaProjectionManager
    private var mediaProjection: MediaProjection? = null

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var bubbleComposeView: ComposeView? = null
    private var selectionComposeView: ComposeView? = null
    private var resultComposeView: ComposeView? = null

    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var selectionParams: WindowManager.LayoutParams
    private lateinit var resultParams: WindowManager.LayoutParams

    private var latestCroppedBitmap: Bitmap? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        mediaProjectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        createNotificationChannel()
        initLayoutParams()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
        
        when (intent?.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val resultData = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)

                if (resultCode == Activity.RESULT_OK && resultData != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        startForeground(
                            NOTIFICATION_ID,
                            createNotification(),
                            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                        )
                    } else {
                        startForeground(NOTIFICATION_ID, createNotification())
                    }

                    // Setup MediaProjection
                    try {
                        mediaProjection = mediaProjectionManager.getMediaProjection(resultCode, resultData)
                    } catch (e: Exception) {
                        Toast.makeText(this, "Gagal memulai perekaman layar: ${e.message}", Toast.LENGTH_SHORT).show()
                        stopSelf()
                        return START_NOT_STICKY
                    }

                    showFloatingBubble()
                } else {
                    stopSelf()
                }
            }
            ACTION_STOP -> {
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun initLayoutParams() {
        // Bubble layout params
        bubbleParams = WindowManager.LayoutParams().apply {
            type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            format = PixelFormat.TRANSLUCENT
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            width = WindowManager.LayoutParams.WRAP_CONTENT
            height = WindowManager.LayoutParams.WRAP_CONTENT
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 400
        }

        // Fullscreen selection layout params
        selectionParams = WindowManager.LayoutParams().apply {
            type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            format = PixelFormat.TRANSLUCENT
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or 
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or 
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            width = WindowManager.LayoutParams.MATCH_PARENT
            height = WindowManager.LayoutParams.MATCH_PARENT
        }

        // Result translation popup params
        resultParams = WindowManager.LayoutParams().apply {
            type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            format = PixelFormat.TRANSLUCENT
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            width = WindowManager.LayoutParams.WRAP_CONTENT
            height = WindowManager.LayoutParams.WRAP_CONTENT
            gravity = Gravity.TOP or Gravity.START
            x = 150
            y = 600
        }
    }

    private fun createComposeView(): ComposeView {
        return ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@FloatingBubbleService)
            setViewTreeSavedStateRegistryOwner(this@FloatingBubbleService)
            setViewTreeViewModelStoreOwner(this@FloatingBubbleService)
        }
    }

    private fun showFloatingBubble() {
        if (bubbleComposeView != null) return

        bubbleComposeView = createComposeView().apply {
            setContent {
                MyApplicationTheme(darkTheme = true, dynamicColor = false) {
                    var isDragging by remember { mutableStateOf(false) }

                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .shadow(8.dp, CircleShape)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                            .clickable {
                                if (!isDragging) {
                                    enterSelectionMode()
                                }
                            }
                            .pointerInput(Unit) {
                                detectDragGestures(
                                    onDragStart = { isDragging = true },
                                    onDragEnd = { isDragging = false },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        bubbleParams.x += dragAmount.x.toInt()
                                        bubbleParams.y += dragAmount.y.toInt()
                                        updateView(bubbleComposeView, bubbleParams)
                                    }
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Translate,
                            contentDescription = "Mulai Terjemahkan",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }
        }
        addView(bubbleComposeView, bubbleParams)
    }

    private fun enterSelectionMode() {
        // Hide bubble and results when selection starts
        hideFloatingBubble()
        hideTranslationResult()

        if (selectionComposeView != null) return

        selectionComposeView = createComposeView().apply {
            setContent {
                MyApplicationTheme(darkTheme = true, dynamicColor = false) {
                    var startPoint by remember { mutableStateOf<Offset?>(null) }
                    var currentPoint by remember { mutableStateOf<Offset?>(null) }

                    val selectionRect = remember(startPoint, currentPoint) {
                        if (startPoint != null && currentPoint != null) {
                            Rect(
                                left = minOf(startPoint!!.x, currentPoint!!.x),
                                top = minOf(startPoint!!.y, currentPoint!!.y),
                                right = maxOf(startPoint!!.x, currentPoint!!.x),
                                bottom = maxOf(startPoint!!.y, currentPoint!!.y)
                            )
                        } else {
                            null
                        }
                    }

                    Box(
                        modifier = Modifier.fillMaxSize()
                    ) {
                        // Drawing Area Canvas
                        Canvas(
                            modifier = Modifier
                                .fillMaxSize()
                                .pointerInput(Unit) {
                                    detectDragGestures(
                                        onDragStart = { offset ->
                                            startPoint = offset
                                            currentPoint = offset
                                        },
                                        onDrag = { change, dragAmount ->
                                            change.consume()
                                            currentPoint = (currentPoint ?: Offset.Zero) + dragAmount
                                        }
                                    )
                                }
                        ) {
                            val rect = selectionRect
                            if (rect != null) {
                                // Draw dark scrim with hole for selection
                                val path = Path().apply {
                                    addRect(Rect(0f, 0f, size.width, size.height))
                                    addRect(rect)
                                    fillType = PathFillType.EvenOdd
                                }
                                drawPath(path, color = Color.Black.copy(alpha = 0.6f))

                                // Draw glowing selection boundary box
                                drawRect(
                                    color = Color(0xFF00E676),
                                    topLeft = rect.topLeft,
                                    size = rect.size,
                                    style = Stroke(width = 3.dp.toPx())
                                )
                            } else {
                                // Draw uniform semi-transparent background
                                drawRect(color = Color.Black.copy(alpha = 0.5f))
                            }
                        }

                        // Instructional Text Header
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 60.dp)
                                .padding(horizontal = 24.dp)
                        ) {
                            Text(
                                text = "Seret kotak di area layar untuk memilih teks manhwa",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 10.dp, horizontal = 16.dp)
                            )
                        }

                        // Action Buttons at Bottom
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 60.dp)
                        ) {
                            Button(
                                onClick = { cancelSelectionMode() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.error
                                )
                            ) {
                                Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Batal")
                            }

                            Button(
                                onClick = {
                                    if (selectionRect != null) {
                                        captureAndProcess(selectionRect)
                                    } else {
                                        Toast.makeText(this@FloatingBubbleService, "Silakan seret kotak di layar terlebih dahulu", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                enabled = selectionRect != null,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF00E676),
                                    contentColor = Color.Black
                                )
                            ) {
                                Icon(Icons.Default.Translate, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Terjemahkan", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
        addView(selectionComposeView, selectionParams)
    }

    private fun cancelSelectionMode() {
        removeView(selectionComposeView)
        selectionComposeView = null
        showFloatingBubble()
    }

    private fun captureAndProcess(rect: Rect) {
        // Remove selection view first so we don't capture the overlay inside the screenshot
        removeView(selectionComposeView)
        selectionComposeView = null

        // Show a brief loading indicator popup overlay immediately
        showLoadingState()

        // Wait slightly for overlay to disappear fully from the screen
        Handler(Looper.getMainLooper()).postDelayed({
            val screenshot = takeScreenshot()
            if (screenshot != null) {
                // Safe crop
                val cropLeft = rect.left.toInt().coerceIn(0, screenshot.width - 1)
                val cropTop = rect.top.toInt().coerceIn(0, screenshot.height - 1)
                val cropWidth = rect.width.toInt().coerceAtMost(screenshot.width - cropLeft).coerceAtLeast(1)
                val cropHeight = rect.height.toInt().coerceAtMost(screenshot.height - cropTop).coerceAtLeast(1)

                try {
                    val cropped = Bitmap.createBitmap(screenshot, cropLeft, cropTop, cropWidth, cropHeight)
                    latestCroppedBitmap = cropped
                    recognizeAndTranslateText(cropped)
                } catch (e: Exception) {
                    showErrorState("Gagal memotong gambar: ${e.message}")
                    showFloatingBubble()
                }
            } else {
                showErrorState("Gagal mengambil screenshot layar")
                showFloatingBubble()
            }
        }, 80.dp.value.toLong()) // tiny safe delay
    }

    private fun takeScreenshot(): Bitmap? {
        val projection = mediaProjection ?: return null
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels

        var screenshotBitmap: Bitmap? = null
        val imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        
        val virtualDisplay = projection.createVirtualDisplay(
            "ManhwaCapture",
            width,
            height,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader.surface,
            null,
            null
        )

        // Give virtual display 50ms to render the surface frame fully
        try {
            Thread.sleep(50)
            val image = imageReader.acquireLatestImage()
            if (image != null) {
                val planes = image.planes
                val buffer = planes[0].buffer
                val pixelStride = planes[0].pixelStride
                val rowStride = planes[0].rowStride
                val rowPadding = rowStride - pixelStride * width
                
                val bitmap = Bitmap.createBitmap(
                    width + rowPadding / pixelStride,
                    height,
                    Bitmap.Config.ARGB_8888
                )
                bitmap.copyPixelsFromBuffer(buffer)
                image.close()

                // Crop row padding out of bitmap if any exists
                screenshotBitmap = if (bitmap.width > width) {
                    Bitmap.createBitmap(bitmap, 0, 0, width, height)
                } else {
                    bitmap
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            virtualDisplay?.release()
            imageReader.close()
        }

        return screenshotBitmap
    }

    private fun recognizeAndTranslateText(bitmap: Bitmap) {
        val image = InputImage.fromBitmap(bitmap, 0)
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

        recognizer.process(image)
            .addOnSuccessListener { visionText ->
                val detectedText = visionText.text.trim().replace("\n", " ")
                if (detectedText.isEmpty()) {
                    showErrorState("Tidak ditemukan teks berbahasa Inggris pada area ini.")
                    showFloatingBubble()
                    return@addOnSuccessListener
                }

                // Call translate
                translateText(detectedText)
            }
            .addOnFailureListener { e ->
                showErrorState("Gagal mengenali teks: ${e.message}")
                showFloatingBubble()
            }
    }

    private fun translateText(text: String) {
        serviceScope.launch {
            try {
                val result = GeminiTranslator.translate(text)
                showTranslationResult(text, result)
            } catch (e: Exception) {
                showErrorState(e.message ?: "Gagal terjemah.")
            } finally {
                showFloatingBubble()
            }
        }
    }

    private fun showLoadingState() {
        hideTranslationResult()
        
        resultComposeView = createComposeView().apply {
            setContent {
                MyApplicationTheme(darkTheme = true, dynamicColor = false) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
                        modifier = Modifier
                            .width(280.dp)
                            .padding(8.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                "Membaca & Menerjemahkan...",
                                color = MaterialTheme.colorScheme.onSurface,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
        addView(resultComposeView, resultParams)
    }

    private fun showErrorState(message: String) {
        hideTranslationResult()

        resultComposeView = createComposeView().apply {
            setContent {
                MyApplicationTheme(darkTheme = true, dynamicColor = false) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
                        modifier = Modifier
                            .width(280.dp)
                            .padding(8.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                Icons.Default.Error,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                message,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                style = MaterialTheme.typography.bodySmall,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { hideTranslationResult() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.onError
                                )
                            ) {
                                Text("Tutup", color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
        addView(resultComposeView, resultParams)
    }

    private fun showTranslationResult(original: String, translated: String) {
        hideTranslationResult()

        resultComposeView = createComposeView().apply {
            setContent {
                MyApplicationTheme(darkTheme = true, dynamicColor = false) {
                    var isCardDragging by remember { mutableStateOf(false) }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
                        modifier = Modifier
                            .width(320.dp)
                            .shadow(12.dp, RoundedCornerShape(16.dp))
                            .border(
                                width = 1.dp,
                                color = MaterialTheme.colorScheme.outlineVariant,
                                shape = RoundedCornerShape(16.dp)
                            )
                            .pointerInput(Unit) {
                                detectDragGestures(
                                    onDragStart = { isCardDragging = true },
                                    onDragEnd = { isCardDragging = false },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        resultParams.x += dragAmount.x.toInt()
                                        resultParams.y += dragAmount.y.toInt()
                                        updateView(resultComposeView, resultParams)
                                    }
                                )
                            }
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                        ) {
                            // Header Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.Translate,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        "Hasil Terjemahan",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                
                                IconButton(
                                    onClick = { hideTranslationResult() },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Close,
                                        contentDescription = "Tutup",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Original text container
                            Text(
                                "ASLI (ENGLISH)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                original,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 4
                            )

                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                            Spacer(modifier = Modifier.height(12.dp))

                            // Translated text container
                            Text(
                                "TERJEMAHAN (INDONESIAN)",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF00E676),
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                translated,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            // Bottom actions row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val clip = ClipData.newPlainText("Terjemahan Manhwa", translated)
                                        clipboard.setPrimaryClip(clip)
                                        Toast.makeText(this@FloatingBubbleService, "Terjemahan disalin ke clipboard", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(vertical = 8.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Copy", fontSize = 12.sp)
                                }

                                Button(
                                    onClick = {
                                        val bitmap = latestCroppedBitmap
                                        if (bitmap != null) {
                                            showLoadingState()
                                            recognizeAndTranslateText(bitmap)
                                        } else {
                                            Toast.makeText(this@FloatingBubbleService, "Tidak ada data gambar lama untuk di-translate ulang", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                    contentPadding = PaddingValues(vertical = 8.dp)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Ulang", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
        addView(resultComposeView, resultParams)
    }

    private fun hideFloatingBubble() {
        removeView(bubbleComposeView)
        bubbleComposeView = null
    }

    private fun hideTranslationResult() {
        removeView(resultComposeView)
        resultComposeView = null
    }

    private fun addView(view: View?, params: WindowManager.LayoutParams) {
        if (view == null) return
        try {
            windowManager.addView(view, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun updateView(view: View?, params: WindowManager.LayoutParams) {
        if (view == null) return
        try {
            windowManager.updateViewLayout(view, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun removeView(view: View?) {
        if (view == null) return
        try {
            windowManager.removeView(view)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Manhwa Translator Service Channel",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Saluran notifikasi untuk tombol melayang Manhwa Translator."
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Manhwa Translator Aktif")
            .setContentText("Tombol melayang siap menerjemahkan teks di layar")
            .setSmallIcon(android.R.drawable.ic_menu_crop)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .build()
    }

    override fun onDestroy() {
        isRunning = false
        hideFloatingBubble()
        hideTranslationResult()
        removeView(selectionComposeView)
        selectionComposeView = null

        mediaProjection?.stop()
        mediaProjection = null

        serviceScope.cancel()

        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        
        super.onDestroy()
    }
}
